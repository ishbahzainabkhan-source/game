import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CartDrawer } from "@/components/cart-drawer";
import { Hero } from "@/components/hero";
import { FeaturedCollections } from "@/components/featured-collections";
import { FeaturedProducts } from "@/components/featured-products";
import { Newsletter } from "@/components/newsletter";

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <FeaturedCollections />
        <FeaturedProducts />
        <Newsletter />
      </main>
      <Footer />
      <CartDrawer />
    </div>
  );
}
