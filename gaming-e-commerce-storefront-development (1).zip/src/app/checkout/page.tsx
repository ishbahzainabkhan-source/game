"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CartDrawer } from "@/components/cart-drawer";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/utils";
import { motion } from "framer-motion";
import {
  Loader2,
  CheckCircle,
  ShoppingBag,
  CreditCard,
  Truck,
  ShieldCheck,
} from "lucide-react";

export default function CheckoutPage() {
  const { items, subtotal, clearCart } = useCart();
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [form, setForm] = useState({
    email: "",
    name: "",
    address: "",
    city: "",
    postalCode: "",
    country: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;

    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          total: subtotal,
          items: items.map((item) => ({
            productId: item.productId,
            name: item.name,
            platform: item.platform,
            quantity: item.quantity,
            price: item.price,
          })),
        }),
      });

      if (res.ok) {
        clearCart();
        setOrderComplete(true);
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (orderComplete) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex flex-1 items-center justify-center px-4 py-20">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md text-center"
          >
            <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-500/15">
              <CheckCircle className="h-10 w-10 text-emerald-400" />
            </div>
            <h1 className="text-3xl font-bold text-white">Order Confirmed!</h1>
            <p className="mt-4 text-void-300">
              Thank you for your purchase. A confirmation email has been sent to{" "}
              {form.email} with your digital codes.
            </p>
            <Link
              href="/products"
              className="mt-8 inline-block rounded-full bg-accent-500 px-8 py-3 font-bold text-white shadow-lg shadow-accent-500/20 hover:bg-accent-600 transition-colors"
            >
              Continue Shopping
            </Link>
          </motion.div>
        </main>
        <Footer />
        <CartDrawer />
      </div>
    );
  }

  if (items.length === 0 && !orderComplete) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex flex-1 items-center justify-center px-4 py-20">
          <div className="text-center">
            <ShoppingBag className="mx-auto h-16 w-16 text-void-500" />
            <h1 className="mt-6 text-2xl font-bold text-white">
              Your cart is empty
            </h1>
            <p className="mt-2 text-void-400">
              Add some games before checking out.
            </p>
            <Link
              href="/products"
              className="mt-6 inline-block rounded-full bg-accent-500 px-8 py-3 font-bold text-white hover:bg-accent-600 transition-colors"
            >
              Browse Games
            </Link>
          </div>
        </main>
        <Footer />
        <CartDrawer />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-white">Checkout</h1>

          <div className="mt-8 grid gap-10 lg:grid-cols-5">
            {/* Form */}
            <form
              onSubmit={handleSubmit}
              className="space-y-6 lg:col-span-3"
            >
              <section className="rounded-2xl border border-white/5 bg-void-900 p-6">
                <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
                  <Truck className="h-5 w-5 text-accent-400" />
                  Shipping Details
                </h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Full Name
                    </label>
                    <input
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Email
                    </label>
                    <input
                      name="email"
                      type="email"
                      value={form.email}
                      onChange={handleChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Address
                    </label>
                    <input
                      name="address"
                      value={form.address}
                      onChange={handleChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      City
                    </label>
                    <input
                      name="city"
                      value={form.city}
                      onChange={handleChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Postal Code
                    </label>
                    <input
                      name="postalCode"
                      value={form.postalCode}
                      onChange={handleChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Country
                    </label>
                    <input
                      name="country"
                      value={form.country}
                      onChange={handleChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                </div>
              </section>

              <section className="rounded-2xl border border-white/5 bg-void-900 p-6">
                <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
                  <CreditCard className="h-5 w-5 text-accent-400" />
                  Payment
                </h2>
                <p className="text-sm text-void-400">
                  This is a demo store. No real payment will be processed.
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Card Number
                    </label>
                    <input
                      placeholder="0000 0000 0000 0000"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Expiry
                    </label>
                    <input
                      placeholder="MM / YY"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      CVC
                    </label>
                    <input
                      placeholder="123"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>
                </div>
              </section>

              <button
                type="submit"
                disabled={submitting}
                className="flex w-full items-center justify-center gap-2 rounded-full bg-accent-500 py-4 text-base font-bold text-white shadow-lg shadow-accent-500/20 hover:bg-accent-600 disabled:opacity-70 transition-colors"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>Pay {formatPrice(subtotal)}</>
                )}
              </button>
            </form>

            {/* Order summary */}
            <div className="lg:col-span-2">
              <div className="sticky top-24 rounded-2xl border border-white/5 bg-void-900 p-6">
                <h2 className="mb-4 text-lg font-semibold text-white">
                  Order Summary
                </h2>
                <ul className="space-y-4">
                  {items.map((item) => (
                    <li key={`${item.productId}-${item.platform}`} className="flex gap-4">
                      <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg">
                        <Image
                          src={item.image}
                          alt={item.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex flex-1 flex-col">
                        <p className="text-sm font-medium text-white line-clamp-1">
                          {item.name}
                        </p>
                        <p className="text-xs text-void-400">
                          {item.platform} &middot; Qty {item.quantity}
                        </p>
                        <p className="mt-auto text-sm font-semibold text-white">
                          {formatPrice(item.price * item.quantity)}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>

                <div className="mt-6 space-y-2 border-t border-white/5 pt-6 text-sm">
                  <div className="flex justify-between text-void-400">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-void-400">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between text-void-400">
                    <span>Tax</span>
                    <span>Included</span>
                  </div>
                  <div className="flex justify-between pt-2 text-base font-bold text-white">
                    <span>Total</span>
                    <span>{formatPrice(subtotal)}</span>
                  </div>
                </div>

                <div className="mt-6 flex items-center gap-2 text-xs text-void-400">
                  <ShieldCheck className="h-4 w-4 text-accent-400" />
                  <span>Secure demo checkout</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
