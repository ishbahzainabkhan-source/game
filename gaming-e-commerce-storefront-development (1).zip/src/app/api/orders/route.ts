import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, name, address, city, postalCode, country, total, items } =
      body;

    if (!email || !name || !address || !city || !postalCode || !country) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    const order = await db
      .insert(orders)
      .values({
        email,
        name,
        address,
        city,
        postalCode,
        country,
        total: String(total),
        items,
      })
      .returning();

    return NextResponse.json({ order: order[0] });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function GET() {
  const allOrders = await db
    .select()
    .from(orders)
    .orderBy(desc(orders.createdAt));
  return NextResponse.json(allOrders);
}
