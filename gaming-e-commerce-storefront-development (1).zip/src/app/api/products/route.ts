import { db } from "@/db";
import { products } from "@/db/schema";
import { sql, asc, desc, SQL } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const category = searchParams.get("category");
  const platform = searchParams.get("platform");
  const featured = searchParams.get("featured");
  const collection = searchParams.get("collection");
  const search = searchParams.get("search");
  const sort = searchParams.get("sort") ?? "featured";

  const conditions: SQL[] = [];

  if (category && category !== "all") {
    conditions.push(sql`${products.category} = ${category}`);
  }
  if (platform && platform !== "all") {
    conditions.push(sql`${platform} = ANY(${products.platform})`);
  }
  if (featured === "true") {
    conditions.push(sql`${products.featured} = true`);
  }
  if (collection) {
    conditions.push(sql`${products.collection} = ${collection}`);
  }
  if (search) {
    conditions.push(
      sql`(
        ${products.name} ILIKE ${`%${search}%`} OR
        ${products.tags}::text ILIKE ${`%${search}%`} OR
        ${products.description} ILIKE ${`%${search}%`}
      )`
    );
  }

  const whereClause =
    conditions.length > 0 ? sql.join(conditions, sql` AND `) : undefined;

  const orderBy: SQL[] = [];
  switch (sort) {
    case "price-asc":
      orderBy.push(asc(products.price));
      break;
    case "price-desc":
      orderBy.push(desc(products.price));
      break;
    case "rating":
      orderBy.push(desc(products.rating));
      break;
    case "newest":
      orderBy.push(desc(products.releaseDate));
      break;
    default:
      orderBy.push(desc(products.featured));
      orderBy.push(desc(products.rating));
  }

  const result = await db
    .select()
    .from(products)
    .where(whereClause)
    .orderBy(...orderBy);

  return NextResponse.json(result);
}
