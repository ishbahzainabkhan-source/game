import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const productRows = await db.select().from(products).where(eq(products.slug, slug));

  if (productRows.length === 0) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  const product = productRows[0];
  const productReviews = await db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, product.id))
    .orderBy(reviews.createdAt);

  return NextResponse.json({ product, reviews: productReviews });
}
