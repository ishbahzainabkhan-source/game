import { db } from "@/db";
import { products } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  const unauthorized = requireAdmin(request);
  if (unauthorized) return unauthorized;

  try {
    const body = await request.json();

    const product = await db
      .insert(products)
      .values({
        name: body.name,
        slug: body.slug,
        description: body.description,
        price: String(body.price),
        comparePrice: body.comparePrice ? String(body.comparePrice) : null,
        images: body.images ?? [],
        stock: Number(body.stock) || 0,
        category: body.category,
        platform: body.platform ?? [],
        tags: body.tags ?? [],
        rating: String(body.rating ?? "0"),
        reviewCount: Number(body.reviewCount ?? 0),
        features: body.features ?? [],
        ageRating: body.ageRating ?? "T",
        releaseDate: body.releaseDate,
        featured: Boolean(body.featured),
        collection: body.collection || null,
      })
      .returning();

    return NextResponse.json({ product: product[0] }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
