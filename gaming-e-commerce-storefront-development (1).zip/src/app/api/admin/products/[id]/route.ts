import { db } from "@/db";
import { products } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const unauthorized = requireAdmin(request);
  if (unauthorized) return unauthorized;

  const { id } = await params;
  const body = await request.json();

  const updateData: Record<string, unknown> = {};
  if (body.name !== undefined) updateData.name = body.name;
  if (body.slug !== undefined) updateData.slug = body.slug;
  if (body.description !== undefined) updateData.description = body.description;
  if (body.price !== undefined) updateData.price = String(body.price);
  if (body.comparePrice !== undefined)
    updateData.comparePrice = body.comparePrice ? String(body.comparePrice) : null;
  if (body.images !== undefined) updateData.images = body.images;
  if (body.stock !== undefined) updateData.stock = Number(body.stock);
  if (body.category !== undefined) updateData.category = body.category;
  if (body.platform !== undefined) updateData.platform = body.platform;
  if (body.tags !== undefined) updateData.tags = body.tags;
  if (body.features !== undefined) updateData.features = body.features;
  if (body.ageRating !== undefined) updateData.ageRating = body.ageRating;
  if (body.releaseDate !== undefined) updateData.releaseDate = body.releaseDate;
  if (body.featured !== undefined) updateData.featured = Boolean(body.featured);
  if (body.collection !== undefined)
    updateData.collection = body.collection || null;

  const updated = await db
    .update(products)
    .set(updateData)
    .where(eq(products.id, Number(id)))
    .returning();

  if (updated.length === 0) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  return NextResponse.json({ product: updated[0] });
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const unauthorized = requireAdmin(request);
  if (unauthorized) return unauthorized;

  const { id } = await params;

  const deleted = await db
    .delete(products)
    .where(eq(products.id, Number(id)))
    .returning();

  if (deleted.length === 0) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  return NextResponse.json({ deleted: true });
}
