"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CartDrawer } from "@/components/cart-drawer";
import { Product, Order } from "@/db/schema";
import { formatPrice } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  Shield,
  LogOut,
  Package,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  CheckCircle,
  Clock,
  XCircle,
  Loader2,
  AlertTriangle,
  Plus,
  Pencil,
  Trash2,
  X,
} from "lucide-react";

const ADMIN_ID = "12345678";

const emptyProductForm = {
  name: "",
  slug: "",
  description: "",
  price: "",
  comparePrice: "",
  stock: "",
  category: "RPG",
  platform: "PC",
  tags: "",
  ageRating: "T",
  releaseDate: "",
  images: "",
  features: "",
  featured: false,
  collection: "",
};

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminId, setAdminId] = useState("");
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState<"dashboard" | "orders" | "products">("dashboard");
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [seedMessage, setSeedMessage] = useState("");

  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState(emptyProductForm);
  const [productFormLoading, setProductFormLoading] = useState(false);
  const [productFormError, setProductFormError] = useState("");
  const [deleteLoading, setDeleteLoading] = useState<number | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("voidadmin");
    if (stored === ADMIN_ID) {
      setIsAuthenticated(true);
    }
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;

    setLoading(true);
    Promise.all([
      fetch("/api/orders").then((res) => res.json()),
      fetch("/api/products").then((res) => res.json()),
    ])
      .then(([ordersData, productsData]) => {
        setOrders(ordersData);
        setProducts(productsData);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [isAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminId === ADMIN_ID) {
      localStorage.setItem("voidadmin", adminId);
      setIsAuthenticated(true);
      setError("");
    } else {
      setError("Invalid admin ID");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("voidadmin");
    setIsAuthenticated(false);
  };

  const handleSeed = async () => {
    setSeedLoading(true);
    setSeedMessage("");
    try {
      const res = await fetch("/api/seed", { method: "POST" });
      const data = await res.json();
      setSeedMessage(data.message || `Seeded: ${data.seeded}`);
      const productsRes = await fetch("/api/products");
      setProducts(await productsRes.json());
    } catch {
      setSeedMessage("Failed to seed");
    } finally {
      setSeedLoading(false);
    }
  };

  const updateOrderStatus = async (id: string, status: string) => {
    await fetch(`/api/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, status } : o))
    );
  };

  const openAddProduct = () => {
    setEditingProduct(null);
    setProductForm(emptyProductForm);
    setProductFormError("");
    setProductModalOpen(true);
  };

  const openEditProduct = (product: Product) => {
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      slug: product.slug,
      description: product.description,
      price: String(product.price),
      comparePrice: product.comparePrice ? String(product.comparePrice) : "",
      stock: String(product.stock),
      category: product.category,
      platform: product.platform.join(", "),
      tags: product.tags.join(", "),
      ageRating: product.ageRating,
      releaseDate: product.releaseDate ?? "",
      images: product.images.join(", "),
      features: product.features.join(", "),
      featured: product.featured,
      collection: product.collection ?? "",
    });
    setProductFormError("");
    setProductModalOpen(true);
  };

  const closeProductModal = () => {
    setProductModalOpen(false);
    setEditingProduct(null);
    setProductForm(emptyProductForm);
    setProductFormError("");
  };

  const handleProductFormChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    setProductForm((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const parseArray = (value: string) =>
    value
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

  const generateSlug = (name: string) =>
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProductFormLoading(true);
    setProductFormError("");

    const slug = productForm.slug.trim() || generateSlug(productForm.name);

    if (!slug) {
      setProductFormError("Please enter a valid product name or slug.");
      setProductFormLoading(false);
      return;
    }

    const duplicate = products.find(
      (p) => p.slug === slug && p.id !== editingProduct?.id
    );
    if (duplicate) {
      setProductFormError(
        `A product with the slug "${slug}" already exists. Please use a unique slug.`
      );
      setProductFormLoading(false);
      return;
    }

    const payload = {
      name: productForm.name.trim(),
      slug,
      description: productForm.description.trim(),
      price: Number(productForm.price),
      comparePrice: productForm.comparePrice
        ? Number(productForm.comparePrice)
        : null,
      stock: Number(productForm.stock),
      category: productForm.category,
      platform: parseArray(productForm.platform),
      tags: parseArray(productForm.tags),
      ageRating: productForm.ageRating,
      releaseDate: productForm.releaseDate.trim() || null,
      images: parseArray(productForm.images),
      features: parseArray(productForm.features),
      featured: productForm.featured,
      collection: productForm.collection || null,
    };

    try {
      const url = editingProduct
        ? `/api/admin/products/${editingProduct.id}`
        : "/api/admin/products";
      const method = editingProduct ? "PATCH" : "POST";

      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          "x-admin-id": ADMIN_ID,
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to save product");
      }

      const productsRes = await fetch("/api/products");
      setProducts(await productsRes.json());
      closeProductModal();
    } catch (err) {
      setProductFormError(
        err instanceof Error ? err.message : "Failed to save product"
      );
    } finally {
      setProductFormLoading(false);
    }
  };

  const handleDeleteProduct = async (id: number) => {
    if (!confirm("Are you sure you want to delete this product?")) return;
    setDeleteLoading(id);
    try {
      const res = await fetch(`/api/admin/products/${id}`, {
        method: "DELETE",
        headers: { "x-admin-id": ADMIN_ID },
      });
      if (res.ok) {
        setProducts((prev) => prev.filter((p) => p.id !== id));
      }
    } finally {
      setDeleteLoading(null);
    }
  };

  const totalRevenue = orders.reduce((sum, o) => sum + Number(o.total), 0);
  const pendingOrders = orders.filter((o) => o.status === "pending").length;
  const completedOrders = orders.filter(
    (o) => o.status === "completed" || o.status === "delivered"
  ).length;

  if (!isAuthenticated) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex flex-1 items-center justify-center px-4 py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md rounded-2xl border border-white/5 bg-void-900 p-8"
          >
            <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-accent-500/15">
              <Shield className="h-7 w-7 text-accent-400" />
            </div>
            <h1 className="text-2xl font-bold text-white">Admin Access</h1>
            <p className="mt-2 text-sm text-void-400">
              Enter your admin ID to manage the store.
            </p>
            <form onSubmit={handleLogin} className="mt-6 space-y-4">
              <div>
                <label className="mb-1 block text-sm font-medium text-void-300">
                  Admin ID
                </label>
                <input
                  type="password"
                  value={adminId}
                  onChange={(e) => setAdminId(e.target.value)}
                  placeholder="Enter admin ID"
                  className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-3 text-white outline-none focus:border-accent-500/50"
                />
              </div>
              {error && (
                <p className="flex items-center gap-2 text-sm text-red-400">
                  <AlertTriangle className="h-4 w-4" />
                  {error}
                </p>
              )}
              <button
                type="submit"
                className="w-full rounded-full bg-accent-500 py-3 font-bold text-white hover:bg-accent-600 transition-colors"
              >
                Sign In
              </button>
            </form>
            <Link
              href="/"
              className="mt-6 block text-center text-sm text-void-400 hover:text-white transition-colors"
            >
              Return to store
            </Link>
          </motion.div>
        </main>
        <Footer />
        <CartDrawer />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
              <p className="text-void-400">Manage orders, products, and seed data.</p>
            </div>
            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-void-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-white/5 transition-colors"
            >
              <LogOut className="h-4 w-4" />
              Sign Out
            </button>
          </div>

          {/* Tabs */}
          <div className="mb-8 flex flex-wrap gap-2">
            {[
              { id: "dashboard", label: "Dashboard", icon: TrendingUp },
              { id: "orders", label: "Orders", icon: ShoppingCart },
              { id: "products", label: "Products", icon: Package },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-colors ${
                  activeTab === tab.id
                    ? "bg-accent-500 text-white"
                    : "bg-void-900 text-void-300 hover:text-white"
                }`}
              >
                <tab.icon className="h-4 w-4" />
                {tab.label}
              </button>
            ))}
            <button
              onClick={handleSeed}
              disabled={seedLoading}
              className="ml-auto inline-flex items-center gap-2 rounded-full bg-emerald-500/15 px-5 py-2.5 text-sm font-semibold text-emerald-400 hover:bg-emerald-500/25 transition-colors disabled:opacity-70"
            >
              {seedLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <TrendingUp className="h-4 w-4" />
              )}
              Seed Demo Data
            </button>
          </div>
          {seedMessage && (
            <p className="mb-6 text-sm text-emerald-400">{seedMessage}</p>
          )}

          {loading ? (
            <div className="flex h-64 items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-accent-400" />
            </div>
          ) : (
            <>
              {activeTab === "dashboard" && (
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                  <DashboardCard
                    icon={DollarSign}
                    label="Total Revenue"
                    value={formatPrice(totalRevenue)}
                  />
                  <DashboardCard
                    icon={ShoppingCart}
                    label="Total Orders"
                    value={orders.length.toString()}
                  />
                  <DashboardCard
                    icon={Clock}
                    label="Pending Orders"
                    value={pendingOrders.toString()}
                  />
                  <DashboardCard
                    icon={CheckCircle}
                    label="Completed Orders"
                    value={completedOrders.toString()}
                  />
                  <DashboardCard
                    icon={Package}
                    label="Products"
                    value={products.length.toString()}
                  />
                </div>
              )}

              {activeTab === "orders" && (
                <div className="overflow-hidden rounded-2xl border border-white/5 bg-void-900">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="border-b border-white/5 bg-void-950 text-void-400">
                        <tr>
                          <th className="px-6 py-4 font-medium">Order ID</th>
                          <th className="px-6 py-4 font-medium">Customer</th>
                          <th className="px-6 py-4 font-medium">Total</th>
                          <th className="px-6 py-4 font-medium">Status</th>
                          <th className="px-6 py-4 font-medium">Date</th>
                          <th className="px-6 py-4 font-medium">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {orders.map((order) => (
                          <tr key={order.id}>
                            <td className="px-6 py-4 font-mono text-void-300">
                              {order.id.slice(0, 8)}...
                            </td>
                            <td className="px-6 py-4 text-white">
                              {order.name}
                              <br />
                              <span className="text-xs text-void-400">
                                {order.email}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-white">
                              {formatPrice(Number(order.total))}
                            </td>
                            <td className="px-6 py-4">
                              <StatusBadge status={order.status} />
                            </td>
                            <td className="px-6 py-4 text-void-400">
                              {new Date(order.createdAt).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4">
                              <select
                                value={order.status}
                                onChange={(e) =>
                                  updateOrderStatus(order.id, e.target.value)
                                }
                                className="rounded-lg border border-white/10 bg-void-950 px-3 py-1.5 text-xs text-white outline-none"
                              >
                                <option value="pending">Pending</option>
                                <option value="processing">Processing</option>
                                <option value="shipped">Shipped</option>
                                <option value="delivered">Delivered</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                              </select>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {orders.length === 0 && (
                    <p className="py-12 text-center text-void-400">
                      No orders yet.
                    </p>
                  )}
                </div>
              )}

              {activeTab === "products" && (
                <div className="overflow-hidden rounded-2xl border border-white/5 bg-void-900">
                  <div className="flex items-center justify-between border-b border-white/5 px-6 py-4">
                    <h2 className="text-lg font-semibold text-white">
                      Products ({products.length})
                    </h2>
                    <button
                      onClick={openAddProduct}
                      className="inline-flex items-center gap-2 rounded-full bg-accent-500 px-4 py-2 text-sm font-semibold text-white hover:bg-accent-600 transition-colors"
                    >
                      <Plus className="h-4 w-4" />
                      Add Product
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="border-b border-white/5 bg-void-950 text-void-400">
                        <tr>
                          <th className="px-6 py-4 font-medium">Name</th>
                          <th className="px-6 py-4 font-medium">Category</th>
                          <th className="px-6 py-4 font-medium">Price</th>
                          <th className="px-6 py-4 font-medium">Stock</th>
                          <th className="px-6 py-4 font-medium">Rating</th>
                          <th className="px-6 py-4 font-medium">Featured</th>
                          <th className="px-6 py-4 font-medium text-right">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {products.map((product) => (
                          <tr key={product.id}>
                            <td className="px-6 py-4">
                              <Link
                                href={`/products/${product.slug}`}
                                className="font-medium text-white hover:text-accent-400 transition-colors"
                              >
                                {product.name}
                              </Link>
                            </td>
                            <td className="px-6 py-4 text-void-300">
                              {product.category}
                            </td>
                            <td className="px-6 py-4 text-white">
                              {formatPrice(Number(product.price))}
                            </td>
                            <td className="px-6 py-4 text-void-300">
                              {product.stock}
                            </td>
                            <td className="px-6 py-4 text-void-300">
                              {product.rating}
                            </td>
                            <td className="px-6 py-4">
                              {product.featured ? (
                                <CheckCircle className="h-5 w-5 text-emerald-400" />
                              ) : (
                                <XCircle className="h-5 w-5 text-void-600" />
                              )}
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => openEditProduct(product)}
                                  className="flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-void-300 hover:bg-accent-500/15 hover:text-accent-400 transition-colors"
                                  aria-label="Edit product"
                                >
                                  <Pencil className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleDeleteProduct(product.id)}
                                  disabled={deleteLoading === product.id}
                                  className="flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-void-300 hover:bg-red-500/15 hover:text-red-400 transition-colors disabled:opacity-50"
                                  aria-label="Delete product"
                                >
                                  {deleteLoading === product.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <Trash2 className="h-4 w-4" />
                                  )}
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      <Footer />
      <CartDrawer />

      {/* Product Modal */}
      <AnimatePresence>
        {productModalOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeProductModal}
              className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="fixed left-1/2 top-1/2 z-50 w-full max-w-2xl -translate-x-1/2 -translate-y-1/2 max-h-[90vh] overflow-y-auto rounded-2xl border border-white/10 bg-void-900 p-6 shadow-2xl"
            >
              <div className="mb-6 flex items-center justify-between">
                <h2 className="text-xl font-bold text-white">
                  {editingProduct ? "Edit Product" : "Add New Product"}
                </h2>
                <button
                  onClick={closeProductModal}
                  className="flex h-8 w-8 items-center justify-center rounded-full text-void-400 hover:bg-white/5 hover:text-white transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleProductSubmit} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Product Name
                    </label>
                    <input
                      name="name"
                      value={productForm.name}
                      onChange={handleProductFormChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Slug
                    </label>
                    <input
                      name="slug"
                      value={productForm.slug}
                      onChange={handleProductFormChange}
                      placeholder="auto-generated from name"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                    {!productForm.slug && productForm.name && (
                      <p className="mt-1 text-xs text-void-400">
                        Will be saved as: {generateSlug(productForm.name)}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Category
                    </label>
                    <select
                      name="category"
                      value={productForm.category}
                      onChange={handleProductFormChange}
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    >
                      {["RPG", "Action", "Racing", "Strategy", "Simulation", "Horror", "Shooter"].map(
                        (c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        )
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Collection
                    </label>
                    <select
                      name="collection"
                      value={productForm.collection}
                      onChange={handleProductFormChange}
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    >
                      <option value="">None</option>
                      {["GAMES", "Editor's Choice", "Top Sellers", "Fan Favorites", "Indie Gems", "Horror Hits", "Most Played", "Cozy Picks"].map(
                        (c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        )
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Price
                    </label>
                    <input
                      name="price"
                      type="number"
                      step="0.01"
                      value={productForm.price}
                      onChange={handleProductFormChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Compare Price
                    </label>
                    <input
                      name="comparePrice"
                      type="number"
                      step="0.01"
                      value={productForm.comparePrice}
                      onChange={handleProductFormChange}
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Stock
                    </label>
                    <input
                      name="stock"
                      type="number"
                      value={productForm.stock}
                      onChange={handleProductFormChange}
                      required
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Age Rating
                    </label>
                    <select
                      name="ageRating"
                      value={productForm.ageRating}
                      onChange={handleProductFormChange}
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    >
                      {["E", "E10+", "T", "M"].map((r) => (
                        <option key={r} value={r}>
                          {r}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Description
                    </label>
                    <textarea
                      name="description"
                      value={productForm.description}
                      onChange={handleProductFormChange}
                      required
                      rows={3}
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Image URLs (comma separated)
                    </label>
                    <input
                      name="images"
                      value={productForm.images}
                      onChange={handleProductFormChange}
                      placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Platforms (comma separated)
                    </label>
                    <input
                      name="platform"
                      value={productForm.platform}
                      onChange={handleProductFormChange}
                      placeholder="PC, PlayStation 5, Xbox Series X"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Tags (comma separated)
                    </label>
                    <input
                      name="tags"
                      value={productForm.tags}
                      onChange={handleProductFormChange}
                      placeholder="Open World, RPG, Fantasy"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Features (comma separated)
                    </label>
                    <input
                      name="features"
                      value={productForm.features}
                      onChange={handleProductFormChange}
                      placeholder="100+ hour campaign, Multiplayer"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-void-300">
                      Release Date
                    </label>
                    <input
                      name="releaseDate"
                      value={productForm.releaseDate}
                      onChange={handleProductFormChange}
                      placeholder="Jan 1, 2025"
                      className="w-full rounded-xl border border-white/10 bg-void-950 px-4 py-2.5 text-white outline-none focus:border-accent-500/50"
                    />
                  </div>



                  <div className="sm:col-span-2 flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="featured"
                      name="featured"
                      checked={productForm.featured}
                      onChange={handleProductFormChange}
                      className="h-4 w-4 rounded border-white/10 bg-void-950 text-accent-500 focus:ring-accent-500"
                    />
                    <label
                      htmlFor="featured"
                      className="text-sm font-medium text-void-300"
                    >
                      Featured product
                    </label>
                  </div>
                </div>

                {productFormError && (
                  <p className="flex items-center gap-2 text-sm text-red-400">
                    <AlertTriangle className="h-4 w-4" />
                    {productFormError}
                  </p>
                )}

                <div className="flex justify-end gap-3 pt-4">
                  <button
                    type="button"
                    onClick={closeProductModal}
                    className="rounded-full border border-white/10 px-6 py-2.5 text-sm font-semibold text-white hover:bg-white/5 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={productFormLoading}
                    className="inline-flex items-center gap-2 rounded-full bg-accent-500 px-6 py-2.5 text-sm font-semibold text-white hover:bg-accent-600 disabled:opacity-70 transition-colors"
                  >
                    {productFormLoading && (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    )}
                    {editingProduct ? "Save Changes" : "Create Product"}
                  </button>
                </div>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function DashboardCard({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl border border-white/5 bg-void-900 p-6">
      <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-accent-500/15">
        <Icon className="h-5 w-5 text-accent-400" />
      </div>
      <p className="text-sm text-void-400">{label}</p>
      <p className="mt-1 text-2xl font-bold text-white">{value}</p>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    pending: "bg-amber-500/15 text-amber-400",
    processing: "bg-sky-500/15 text-sky-400",
    shipped: "bg-indigo-500/15 text-indigo-400",
    delivered: "bg-emerald-500/15 text-emerald-400",
    completed: "bg-emerald-500/15 text-emerald-400",
    cancelled: "bg-red-500/15 text-red-400",
  };
  return (
    <span
      className={`rounded-full px-2.5 py-1 text-xs font-medium ${colors[status] || colors.pending}`}
    >
      {status}
    </span>
  );
}
