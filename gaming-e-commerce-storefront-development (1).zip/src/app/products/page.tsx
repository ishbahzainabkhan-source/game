"use client";

import { useEffect, useState, useMemo, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CartDrawer } from "@/components/cart-drawer";
import { ProductCard } from "@/components/product-card";
import { Product } from "@/db/schema";
import { Search, SlidersHorizontal, X, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const categories = [
  "All",
  "RPG",
  "Action",
  "Racing",
  "Strategy",
  "Simulation",
  "Horror",
  "Shooter",
];

const platforms = [
  "All",
  "PC",
  "PlayStation 5",
  "Xbox Series X",
  "Nintendo Switch",
];

const sortOptions = [
  { value: "featured", label: "Featured" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating", label: "Highest Rated" },
  { value: "newest", label: "Newest" },
];

function ProductsPageContent() {
  const searchParams = useSearchParams();
  const initialCategory = searchParams.get("category") ?? "All";
  const initialCollection = searchParams.get("collection");
  const initialSearch = searchParams.get("search") ?? "";

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState(initialCategory);
  const [platform, setPlatform] = useState("All");
  const [sort, setSort] = useState("featured");
  const [search, setSearch] = useState(initialSearch);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams();
    if (category !== "All") params.set("category", category);
    if (platform !== "All") params.set("platform", platform);
    if (sort !== "featured") params.set("sort", sort);
    if (search) params.set("search", search);
    if (initialCollection) params.set("collection", initialCollection);

    setLoading(true);
    fetch(`/api/products?${params.toString()}`)
      .then((res) => res.json())
      .then((data) => {
        setProducts(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [category, platform, sort, search, initialCollection]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (category !== "All") count++;
    if (platform !== "All") count++;
    if (search) count++;
    return count;
  }, [category, platform, search]);

  const clearFilters = () => {
    setCategory("All");
    setPlatform("All");
    setSearch("");
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white sm:text-4xl">
              {initialCollection ? initialCollection : "All Games"}
            </h1>
            <p className="mt-2 text-void-400">
              {initialCollection
                ? `Browse our ${initialCollection} collection.`
                : "Browse our full catalog of premium titles."}
            </p>
          </div>

          {/* Toolbar */}
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-void-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search games, tags, genres..."
                className="w-full rounded-full border border-white/10 bg-void-900 py-2.5 pl-10 pr-4 text-sm text-white placeholder:text-void-500 outline-none focus:border-accent-500/50"
              />
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setMobileFiltersOpen(true)}
                className="flex items-center gap-2 rounded-full border border-white/10 bg-void-900 px-4 py-2.5 text-sm font-medium text-white sm:hidden"
              >
                <SlidersHorizontal className="h-4 w-4" />
                Filters
                {activeFiltersCount > 0 && (
                  <span className="ml-1 flex h-5 w-5 items-center justify-center rounded-full bg-accent-500 text-xs">
                    {activeFiltersCount}
                  </span>
                )}
              </button>

              <div className="relative">
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                  className="appearance-none rounded-full border border-white/10 bg-void-900 py-2.5 pl-4 pr-10 text-sm font-medium text-white outline-none focus:border-accent-500/50"
                >
                  {sortOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-void-400" />
              </div>
            </div>
          </div>

          <div className="flex gap-8">
            {/* Desktop filters */}
            <aside className="hidden w-64 flex-shrink-0 sm:block">
              <div className="sticky top-24 space-y-8">
                <div>
                  <h3 className="mb-4 text-sm font-semibold text-white">
                    Category
                  </h3>
                  <div className="space-y-2">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setCategory(cat)}
                        className={`block w-full rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                          category === cat
                            ? "bg-accent-500/15 text-accent-300 font-medium"
                            : "text-void-300 hover:bg-white/5 hover:text-white"
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="mb-4 text-sm font-semibold text-white">
                    Platform
                  </h3>
                  <div className="space-y-2">
                    {platforms.map((plat) => (
                      <button
                        key={plat}
                        onClick={() => setPlatform(plat)}
                        className={`block w-full rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                          platform === plat
                            ? "bg-accent-500/15 text-accent-300 font-medium"
                            : "text-void-300 hover:bg-white/5 hover:text-white"
                        }`}
                      >
                        {plat}
                      </button>
                    ))}
                  </div>
                </div>

                {activeFiltersCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="flex items-center gap-2 text-sm font-medium text-void-400 hover:text-white transition-colors"
                  >
                    <X className="h-4 w-4" />
                    Clear filters
                  </button>
                )}
              </div>
            </aside>

            {/* Product grid */}
            <div className="flex-1">
              {loading ? (
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div
                      key={i}
                      className="h-96 animate-pulse rounded-2xl bg-void-800"
                    />
                  ))}
                </div>
              ) : products.length === 0 ? (
                <div className="flex h-96 flex-col items-center justify-center rounded-2xl border border-white/5 bg-void-900 text-center">
                  <p className="text-lg font-medium text-white">
                    No games found
                  </p>
                  <p className="mt-1 text-sm text-void-400">
                    Try adjusting your filters or search query.
                  </p>
                  <button
                    onClick={clearFilters}
                    className="mt-4 rounded-full bg-accent-500 px-5 py-2 text-sm font-semibold text-white hover:bg-accent-600 transition-colors"
                  >
                    Clear filters
                  </button>
                </div>
              ) : (
                <>
                  <p className="mb-4 text-sm text-void-400">
                    Showing {products.length} game
                    {products.length !== 1 ? "s" : ""}
                  </p>
                  <motion.div
                    layout
                    className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
                  >
                    <AnimatePresence>
                      {products.map((product) => (
                        <ProductCard key={product.id} product={product} />
                      ))}
                    </AnimatePresence>
                  </motion.div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <CartDrawer />

      {/* Mobile filters drawer */}
      <AnimatePresence>
        {mobileFiltersOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileFiltersOpen(false)}
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm sm:hidden"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 z-50 max-h-[80vh] overflow-y-auto rounded-t-3xl bg-void-900 p-6 sm:hidden"
            >
              <div className="mb-6 flex items-center justify-between">
                <h2 className="text-lg font-semibold text-white">Filters</h2>
                <button
                  onClick={() => setMobileFiltersOpen(false)}
                  className="flex h-8 w-8 items-center justify-center rounded-full text-void-400 hover:bg-white/5"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="mb-6">
                <h3 className="mb-3 text-sm font-semibold text-white">
                  Category
                </h3>
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setCategory(cat)}
                      className={`rounded-full px-3 py-1.5 text-sm transition-colors ${
                        category === cat
                          ? "bg-accent-500 text-white"
                          : "bg-white/5 text-void-300 hover:bg-white/10"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h3 className="mb-3 text-sm font-semibold text-white">
                  Platform
                </h3>
                <div className="flex flex-wrap gap-2">
                  {platforms.map((plat) => (
                    <button
                      key={plat}
                      onClick={() => setPlatform(plat)}
                      className={`rounded-full px-3 py-1.5 text-sm transition-colors ${
                        platform === plat
                          ? "bg-accent-500 text-white"
                          : "bg-white/5 text-void-300 hover:bg-white/10"
                      }`}
                    >
                      {plat}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setMobileFiltersOpen(false)}
                className="w-full rounded-full bg-accent-500 py-3 text-sm font-bold text-white hover:bg-accent-600 transition-colors"
              >
                Show {products.length} games
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function ProductsPage() {
  return (
    <Suspense fallback={null}>
      <ProductsPageContent />
    </Suspense>
  );
}
