"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CartDrawer } from "@/components/cart-drawer";
import { ProductCard } from "@/components/product-card";
import { Product, Review } from "@/db/schema";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/utils";
import {
  Star,
  ShoppingCart,
  Check,
  ChevronRight,
  Calendar,
  Shield,
  Download,
  ThumbsUp,
  AlertCircle,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ProductDetailPage() {
  const params = useParams();
  const slug = params.slug as string;
  const { addToCart } = useCart();

  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [related, setRelated] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedPlatform, setSelectedPlatform] = useState("");
  const [added, setAdded] = useState(false);
  const [activeTab, setActiveTab] = useState<"description" | "reviews">("description");

  useEffect(() => {
    fetch(`/api/products/${slug}`)
      .then((res) => res.json())
      .then((data) => {
        setProduct(data.product);
        setReviews(data.reviews);
        setSelectedPlatform(data.product.platform[0] ?? "PC");
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [slug]);

  useEffect(() => {
    if (product) {
      fetch(`/api/products?category=${product.category}&limit=4`)
        .then((res) => res.json())
        .then((data) => {
          setRelated(data.filter((p: Product) => p.id !== product.id).slice(0, 4));
        });
    }
  }, [product]);

  const handleAddToCart = () => {
    if (!product) return;
    addToCart({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      price: Number(product.price),
      image: product.images[0] ?? "",
      platform: selectedPlatform,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 py-10">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="h-8 w-32 animate-pulse rounded bg-void-800" />
            <div className="mt-8 grid gap-8 lg:grid-cols-2">
              <div className="aspect-square animate-pulse rounded-2xl bg-void-800" />
              <div className="space-y-4">
                <div className="h-10 w-3/4 animate-pulse rounded bg-void-800" />
                <div className="h-6 w-1/4 animate-pulse rounded bg-void-800" />
                <div className="h-32 w-full animate-pulse rounded bg-void-800" />
              </div>
            </div>
          </div>
        </main>
        <Footer />
        <CartDrawer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-void-500" />
            <h1 className="mt-4 text-2xl font-bold text-white">
              Product not found
            </h1>
            <Link
              href="/products"
              className="mt-4 inline-block rounded-full bg-accent-500 px-6 py-2 text-sm font-semibold text-white hover:bg-accent-600"
            >
              Back to shop
            </Link>
          </div>
        </main>
        <Footer />
        <CartDrawer />
      </div>
    );
  }

  const averageRating =
    reviews.length > 0
      ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
      : product.rating;

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Breadcrumb */}
          <nav className="mb-6 flex items-center gap-2 text-sm text-void-400">
            <Link href="/" className="hover:text-white transition-colors">
              Home
            </Link>
            <ChevronRight className="h-4 w-4" />
            <Link href="/products" className="hover:text-white transition-colors">
              Shop
            </Link>
            <ChevronRight className="h-4 w-4" />
            <span className="text-white">{product.name}</span>
          </nav>

          <div className="grid gap-10 lg:grid-cols-2">
            {/* Image gallery */}
            <div>
              <div className="relative aspect-[16/10] overflow-hidden rounded-2xl border border-white/5 bg-void-900">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={selectedImage}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="absolute inset-0"
                  >
                    <Image
                      src={product.images[selectedImage] ?? ""}
                      alt={product.name}
                      fill
                      className="object-cover"
                      priority
                    />
                  </motion.div>
                </AnimatePresence>
              </div>
              <div className="mt-4 grid grid-cols-4 gap-3">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`relative aspect-video overflow-hidden rounded-lg border-2 transition-all ${
                      selectedImage === index
                        ? "border-accent-500"
                        : "border-transparent hover:border-white/20"
                    }`}
                  >
                    <Image
                      src={image}
                      alt={`${product.name} screenshot ${index + 1}`}
                      fill
                      className="object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product info */}
            <div>
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <span className="rounded-md bg-white/5 px-2.5 py-1 text-xs font-medium text-void-300">
                  {product.category}
                </span>
                <span className="rounded-md bg-white/5 px-2.5 py-1 text-xs font-medium text-void-300">
                  {product.ageRating}
                </span>
                {product.comparePrice && (
                  <span className="rounded-md bg-red-500/15 px-2.5 py-1 text-xs font-bold text-red-400">
                    Sale
                  </span>
                )}
              </div>

              <h1 className="text-3xl font-bold text-white sm:text-4xl">
                {product.name}
              </h1>

              <div className="mt-3 flex items-center gap-4">
                <div className="flex items-center gap-1 text-amber-400">
                  <Star className="h-5 w-5 fill-current" />
                  <span className="font-bold text-white">{averageRating}</span>
                </div>
                <span className="text-void-400">
                  {reviews.length || product.reviewCount} reviews
                </span>
              </div>

              <div className="mt-6 flex items-baseline gap-3">
                <span className="text-4xl font-bold text-white">
                  {formatPrice(Number(product.price))}
                </span>
                {product.comparePrice && (
                  <span className="text-xl text-void-500 line-through">
                    {formatPrice(Number(product.comparePrice))}
                  </span>
                )}
              </div>

              <p className="mt-6 text-void-300 leading-relaxed">
                {product.description}
              </p>

              <div className="mt-8 space-y-4">
                <div>
                  <label className="mb-2 block text-sm font-medium text-white">
                    Platform
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {product.platform.map((plat) => (
                      <button
                        key={plat}
                        onClick={() => setSelectedPlatform(plat)}
                        className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                          selectedPlatform === plat
                            ? "bg-accent-500 text-white"
                            : "bg-white/5 text-void-300 hover:bg-white/10"
                        }`}
                      >
                        {plat}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleAddToCart}
                  className={`flex w-full items-center justify-center gap-2 rounded-full py-4 text-base font-bold text-white shadow-lg transition-all ${
                    added
                      ? "bg-emerald-500 shadow-emerald-500/20"
                      : "bg-accent-500 shadow-accent-500/20 hover:bg-accent-600"
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="h-5 w-5" />
                      Added to Cart
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="h-5 w-5" />
                      Add to Cart
                    </>
                  )}
                </button>
              </div>

              <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div className="flex items-center gap-3 rounded-xl bg-void-900 p-4">
                  <Download className="h-5 w-5 text-accent-400" />
                  <div>
                    <p className="text-xs text-void-400">Delivery</p>
                    <p className="text-sm font-medium text-white">Instant Digital</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 rounded-xl bg-void-900 p-4">
                  <Shield className="h-5 w-5 text-accent-400" />
                  <div>
                    <p className="text-xs text-void-400">Guarantee</p>
                    <p className="text-sm font-medium text-white">30-Day Refund</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 rounded-xl bg-void-900 p-4">
                  <Calendar className="h-5 w-5 text-accent-400" />
                  <div>
                    <p className="text-xs text-void-400">Released</p>
                    <p className="text-sm font-medium text-white">
                      {product.releaseDate}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="mt-16">
            <div className="flex gap-6 border-b border-white/10">
              <button
                onClick={() => setActiveTab("description")}
                className={`border-b-2 pb-3 text-sm font-semibold transition-colors ${
                  activeTab === "description"
                    ? "border-accent-500 text-accent-400"
                    : "border-transparent text-void-400 hover:text-white"
                }`}
              >
                Description & Features
              </button>
              <button
                onClick={() => setActiveTab("reviews")}
                className={`border-b-2 pb-3 text-sm font-semibold transition-colors ${
                  activeTab === "reviews"
                    ? "border-accent-500 text-accent-400"
                    : "border-transparent text-void-400 hover:text-white"
                }`}
              >
                Reviews ({reviews.length || product.reviewCount})
              </button>
            </div>

            <div className="py-8">
              {activeTab === "description" ? (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <h3 className="mb-4 text-lg font-semibold text-white">
                    Key Features
                  </h3>
                  <ul className="grid gap-3 sm:grid-cols-2">
                    {product.features.map((feature, index) => (
                      <li
                        key={index}
                        className="flex items-start gap-3 rounded-xl bg-void-900 p-4"
                      >
                        <Check className="mt-0.5 h-5 w-5 flex-shrink-0 text-accent-400" />
                        <span className="text-void-200">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-8">
                    <h3 className="mb-4 text-lg font-semibold text-white">
                      About this game
                    </h3>
                    <p className="max-w-3xl leading-relaxed text-void-300">
                      {product.description} Dive into a meticulously crafted
                      experience with stunning visuals, responsive gameplay, and
                      a community of passionate players. Whether you are
                      looking for a weekend adventure or your next hundred-hour
                      obsession, {product.name} delivers.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  {reviews.length === 0 ? (
                    <p className="text-void-400">No reviews yet.</p>
                  ) : (
                    reviews.map((review) => (
                      <div
                        key={review.id}
                        className="rounded-2xl border border-white/5 bg-void-900 p-6"
                      >
                        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <p className="font-semibold text-white">
                              {review.author}
                              {review.verified && (
                                <span className="ml-2 rounded-full bg-emerald-500/15 px-2 py-0.5 text-xs font-medium text-emerald-400">
                                  Verified
                                </span>
                              )}
                            </p>
                            <div className="mt-1 flex items-center gap-1 text-amber-400">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < review.rating
                                      ? "fill-current"
                                      : "text-void-600"
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <span className="text-xs text-void-500">
                            {new Date(review.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <h4 className="mb-1 font-medium text-white">
                          {review.title}
                        </h4>
                        <p className="text-sm text-void-300">{review.body}</p>
                        <button className="mt-4 flex items-center gap-1.5 text-xs font-medium text-void-400 hover:text-white transition-colors">
                          <ThumbsUp className="h-3.5 w-3.5" />
                          Helpful ({review.helpful})
                        </button>
                      </div>
                    ))
                  )}
                </motion.div>
              )}
            </div>
          </div>

          {/* Related products */}
          {related.length > 0 && (
            <section className="mt-16">
              <h2 className="mb-6 text-2xl font-bold text-white">
                You may also like
              </h2>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {related.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
