"use client";

import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";

const collections = [
  {
    name: "GAMES",
    description: "The ultimate destination for every title in our catalog.",
    image:
      "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=800&q=80",
    href: "/products?collection=GAMES",
    color: "from-violet-600 to-fuchsia-500",
  },
  {
    name: "Editor's Choice",
    description: "Hand-picked masterpieces every gamer should play.",
    image:
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80",
    href: "/products?collection=Editor's Choice",
    color: "from-accent-600 to-accent-400",
  },
  {
    name: "Top Sellers",
    description: "The games everyone is talking about right now.",
    image:
      "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?auto=format&fit=crop&w=800&q=80",
    href: "/products?collection=Top Sellers",
    color: "from-rose-600 to-orange-500",
  },
  {
    name: "Indie Gems",
    description: "Unique experiences from bold independent studios.",
    image:
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80",
    href: "/products?collection=Indie Gems",
    color: "from-emerald-600 to-teal-400",
  },
  {
    name: "Cozy Picks",
    description: "Relaxing worlds perfect for winding down.",
    image:
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80",
    href: "/products?collection=Cozy Picks",
    color: "from-sky-600 to-indigo-400",
  },
];

export function FeaturedCollections() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center"
        >
          <h2 className="text-3xl font-bold text-white sm:text-4xl">
            Featured Collections
          </h2>
          <p className="mt-3 text-void-400">
            Curated playlists for every mood and playstyle.
          </p>
        </motion.div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
          {collections.map((collection, index) => (
            <motion.div
              key={collection.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Link
                href={collection.href}
                className="group relative flex h-80 flex-col justify-end overflow-hidden rounded-2xl border border-white/5 bg-void-900 p-6"
              >
                <Image
                  src={collection.image}
                  alt={collection.name}
                  fill
                  className="object-cover opacity-50 transition-transform duration-500 group-hover:scale-110"
                />
                <div
                  className={`absolute inset-0 bg-gradient-to-t ${collection.color} opacity-20 group-hover:opacity-30 transition-opacity`}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-void-950 via-void-950/60 to-transparent" />
                <div className="relative">
                  <h3 className="text-xl font-bold text-white">
                    {collection.name}
                  </h3>
                  <p className="mt-1 text-sm text-void-300">
                    {collection.description}
                  </p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
