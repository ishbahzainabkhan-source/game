"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, CheckCircle } from "lucide-react";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      setEmail("");
    }
  };

  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-accent-600 to-accent-500 px-6 py-16 text-center shadow-2xl shadow-accent-500/20 sm:px-16"
        >
          <div className="relative z-10">
            <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm">
              <Mail className="h-7 w-7 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white sm:text-4xl">
              Never miss a launch
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-accent-100">
              Join 50,000+ gamers getting exclusive deals, release alerts, and
              curator picks delivered to their inbox.
            </p>

            {submitted ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-white/20 px-6 py-3 text-white backdrop-blur-sm"
              >
                <CheckCircle className="h-5 w-5" />
                <span className="font-medium">You're on the list!</span>
              </motion.div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
              >
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="flex-1 rounded-full bg-white/10 px-5 py-3 text-white placeholder:text-white/60 outline-none ring-white/30 focus:ring-2 backdrop-blur-sm"
                />
                <button
                  type="submit"
                  className="rounded-full bg-white px-6 py-3 font-bold text-accent-600 shadow-lg transition-transform hover:scale-105"
                >
                  Subscribe
                </button>
              </form>
            )}
          </div>

          {/* Decorative circles */}
          <div className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
          <div className="absolute -bottom-20 -right-20 h-80 w-80 rounded-full bg-white/10 blur-3xl" />
        </motion.div>
      </div>
    </section>
  );
}
