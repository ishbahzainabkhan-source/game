"use client";

import Link from "next/link";
import Image from "next/image";
import { Product } from "@/db/schema";
import { formatPrice } from "@/lib/utils";
import { Star, ShoppingCart } from "lucide-react";
import { motion } from "framer-motion";
import { useCart } from "@/lib/cart-context";

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const firstPlatform = product.platform[0] ?? "PC";

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4 }}
      className="group relative flex flex-col overflow-hidden rounded-2xl bg-void-900 border border-white/5 shadow-sm hover:shadow-xl hover:shadow-accent-500/10 transition-all duration-300"
    >
      <Link href={`/products/${product.slug}`} className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={product.images[0] ?? "/placeholder.jpg"}
          alt={product.name}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-void-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        {product.comparePrice && (
          <span className="absolute left-3 top-3 rounded-full bg-red-500/90 px-2.5 py-1 text-xs font-bold text-white backdrop-blur-sm">
            Sale
          </span>
        )}
        {product.featured && !product.comparePrice && (
          <span className="absolute left-3 top-3 rounded-full bg-accent-500/90 px-2.5 py-1 text-xs font-bold text-white backdrop-blur-sm">
            Featured
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col p-4">
        <div className="mb-2 flex items-center gap-2 text-xs text-void-400">
          <span className="rounded-md bg-white/5 px-2 py-0.5">{product.category}</span>
          <span className="flex items-center gap-1 text-amber-400">
            <Star className="h-3 w-3 fill-current" />
            {product.rating}
          </span>
          <span>({product.reviewCount})</span>
        </div>

        <Link href={`/products/${product.slug}`}>
          <h3 className="mb-1 text-base font-semibold text-white group-hover:text-accent-400 transition-colors line-clamp-1">
            {product.name}
          </h3>
        </Link>

        <p className="mb-4 line-clamp-2 text-sm text-void-400">
          {product.description}
        </p>

        <div className="mt-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-white">
              {formatPrice(Number(product.price))}
            </span>
            {product.comparePrice && (
              <span className="text-sm text-void-500 line-through">
                {formatPrice(Number(product.comparePrice))}
              </span>
            )}
          </div>
          <button
            onClick={() =>
              addToCart({
                productId: product.id,
                slug: product.slug,
                name: product.name,
                price: Number(product.price),
                image: product.images[0] ?? "",
                platform: firstPlatform,
              })
            }
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-white hover:bg-accent-500 hover:shadow-lg hover:shadow-accent-500/25 transition-all"
            aria-label="Add to cart"
          >
            <ShoppingCart className="h-4 w-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
