import Link from "next/link";
import { Gamepad2, Globe, Mail, MessageCircle, Trophy } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-white/5 bg-void-900">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-accent-500 to-accent-600 text-white">
                <Gamepad2 className="h-5 w-5" />
              </div>
              <span className="text-lg font-bold text-white">
                Void<span className="text-accent-400">Games</span>
              </span>
            </Link>
            <p className="mt-4 text-sm text-void-400">
              Premium games for every kind of gamer. From epic RPGs to cozy
              sims, discover your next obsession.
            </p>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">Shop</h4>
            <ul className="space-y-2 text-sm text-void-400">
              <li>
                <Link href="/products" className="hover:text-accent-400 transition-colors">
                  All Games
                </Link>
              </li>
              <li>
                <Link href="/products?collection=GAMES" className="hover:text-accent-400 transition-colors">
                  GAMES
                </Link>
              </li>
              <li>
                <Link href="/products?collection=Editor's Choice" className="hover:text-accent-400 transition-colors">
                  Editor's Choice
                </Link>
              </li>
              <li>
                <Link href="/products?collection=Top Sellers" className="hover:text-accent-400 transition-colors">
                  Top Sellers
                </Link>
              </li>
              <li>
                <Link href="/products?collection=Indie Gems" className="hover:text-accent-400 transition-colors">
                  Indie Gems
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">Support</h4>
            <ul className="space-y-2 text-sm text-void-400">
              <li>
                <Link href="#" className="hover:text-accent-400 transition-colors">
                  Help Center
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-accent-400 transition-colors">
                  Order Status
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-accent-400 transition-colors">
                  Returns
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-accent-400 transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">Connect</h4>
            <div className="flex gap-3">
              <a
                href="#"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-void-400 hover:bg-accent-500 hover:text-white transition-colors"
                aria-label="Website"
              >
                <Globe className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-void-400 hover:bg-accent-500 hover:text-white transition-colors"
                aria-label="Newsletter"
              >
                <Mail className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-void-400 hover:bg-accent-500 hover:text-white transition-colors"
                aria-label="Community"
              >
                <MessageCircle className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-void-400 hover:bg-accent-500 hover:text-white transition-colors"
                aria-label="Leaderboards"
              >
                <Trophy className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-8 md:flex-row">
          <p className="text-xs text-void-500">
            &copy; {new Date().getFullYear()} Void Games. All rights reserved.
          </p>
          <div className="flex gap-6 text-xs text-void-500">
            <Link href="#" className="hover:text-void-300 transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:text-void-300 transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
