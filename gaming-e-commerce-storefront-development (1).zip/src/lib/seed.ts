import { db } from "@/db";
import { products, reviews } from "@/db/schema";

const productData = [
  {
    name: "Aether Chronicles: Origins",
    slug: "aether-chronicles-origins",
    description:
      "Embark on an epic JRPG adventure across floating sky-cities and forgotten underground realms. Forge alliances, master elemental magic, and uncover the truth behind the Aether Rift.",
    price: "59.99",
    comparePrice: "69.99",
    images: [
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 120,
    category: "RPG",
    platform: ["PC", "PlayStation 5", "Xbox Series X"],
    tags: ["Open World", "Story Rich", "Fantasy", "JRPG"],
    rating: "4.8",
    reviewCount: 342,
    features: [
      "100+ hour campaign",
      "Deep character customization",
      "Real-time tactical combat",
      "Orchestral soundtrack",
    ],
    ageRating: "T",
    releaseDate: "Mar 14, 2025",
    featured: true,
    collection: "Editor's Choice",
  },
  {
    name: "Neon Overdrive",
    slug: "neon-overdrive",
    description:
      "A blistering synthwave racing experience where speed is currency. Drift through cyberpunk megacities, customize your ride with neon-lit parts, and outrun rival crews in online leagues.",
    price: "39.99",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1511882150382-421056ac8d54?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 85,
    category: "Racing",
    platform: ["PC", "PlayStation 5", "Xbox Series X", "Nintendo Switch"],
    tags: ["Multiplayer", "Arcade", "Cyberpunk", "Racing"],
    rating: "4.6",
    reviewCount: 189,
    features: [
      "120 licensed tracks",
      "Cross-platform multiplayer",
      "Deep vehicle tuning",
      "Photo mode",
    ],
    ageRating: "E10+",
    releaseDate: "Jan 22, 2025",
    featured: true,
    collection: "Top Sellers",
  },
  {
    name: "Shadows of Eldoria",
    slug: "shadows-of-eldoria",
    description:
      "A dark fantasy souls-like action RPG. Brave cursed kingdoms, face towering bosses, and master punishing combat where every parry and dodge matters.",
    price: "49.99",
    comparePrice: "59.99",
    images: [
      "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560253023-3ec5d502959f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 64,
    category: "Action",
    platform: ["PC", "PlayStation 5", "Xbox Series X"],
    tags: ["Souls-like", "Difficult", "Atmospheric", "Action RPG"],
    rating: "4.7",
    reviewCount: 512,
    features: [
      "Challenging boss encounters",
      "Interconnected world design",
      "Weapon crafting system",
      "New Game+ with remixes",
    ],
    ageRating: "M",
    releaseDate: "Nov 8, 2024",
    featured: true,
    collection: "Fan Favorites",
  },
  {
    name: "Stellar Command",
    slug: "stellar-command",
    description:
      "Command a fleet through a procedurally generated galaxy. Build colonies, negotiate with alien factions, and engage in tactical fleet battles in this grand strategy masterpiece.",
    price: "44.99",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1614728853911-006395542329?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 95,
    category: "Strategy",
    platform: ["PC"],
    tags: ["4X", "Space", "Procedural", "Grand Strategy"],
    rating: "4.5",
    reviewCount: 127,
    features: [
      "Procedural galaxies",
      "Diplomacy and espionage",
      "Real-time fleet combat",
      "Mod support",
    ],
    ageRating: "T",
    releaseDate: "Feb 4, 2025",
    featured: false,
    collection: null,
  },
  {
    name: "Pixel Kingdoms",
    slug: "pixel-kingdoms",
    description:
      "A charming pixel-art kingdom builder. Gather resources, defend against goblin raids, and expand your tiny realm into a bustling medieval empire.",
    price: "24.99",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1605901309584-818e25960a8f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1552820728-8b83bb6b2b0a?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 200,
    category: "Simulation",
    platform: ["PC", "Nintendo Switch"],
    tags: ["Pixel Art", "City Builder", "Relaxing", "Indie"],
    rating: "4.4",
    reviewCount: 234,
    features: [
      "Infinite sandbox maps",
      "Seasonal events",
      "Co-op multiplayer",
      "Steam Workshop support",
    ],
    ageRating: "E",
    releaseDate: "Oct 30, 2024",
    featured: true,
    collection: "Indie Gems",
  },
  {
    name: "Cyber Heist: Zero Day",
    slug: "cyber-heist-zero-day",
    description:
      "Assemble a crew of hackers and infiltrate the world's most secure corporate networks. Plan heists, hack systems in real-time, and escape before security traces you.",
    price: "34.99",
    comparePrice: "39.99",
    images: [
      "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 73,
    category: "Action",
    platform: ["PC", "PlayStation 5", "Xbox Series X"],
    tags: ["Stealth", "Cyberpunk", "Tactical", "Heist"],
    rating: "4.3",
    reviewCount: 156,
    features: [
      "Open-ended missions",
      "Realistic hacking puzzles",
      "Co-op campaign",
      "Dynamic security AI",
    ],
    ageRating: "M",
    releaseDate: "Dec 12, 2024",
    featured: false,
    collection: null,
  },
  {
    name: "Echoes of the Void",
    slug: "echoes-of-the-void",
    description:
      "A haunting narrative horror game set aboard a derelict space station. Solve environmental puzzles, manage scarce resources, and uncover what happened to the crew.",
    price: "29.99",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1506318137071-a8bcbf6d9436?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 58,
    category: "Horror",
    platform: ["PC", "PlayStation 5", "Xbox Series X"],
    tags: ["Horror", "Sci-Fi", "Story Rich", "Atmospheric"],
    rating: "4.6",
    reviewCount: 198,
    features: [
      "Immersive sound design",
      "Multiple endings",
      "No combat, pure tension",
      "Ray-traced lighting",
    ],
    ageRating: "M",
    releaseDate: "Sep 20, 2024",
    featured: true,
    collection: "Horror Hits",
  },
  {
    name: "Mythic Arena",
    slug: "mythic-arena",
    description:
      "A free-to-play hero shooter where legends clash. Choose from gods, monsters, and mythic warriors in fast-paced 5v5 battles across iconic arenas.",
    price: "0.00",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1534423861386-85a16f5d13fd?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1519669556878-63bdad8a1a49?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 9999,
    category: "Shooter",
    platform: ["PC", "PlayStation 5", "Xbox Series X"],
    tags: ["Free to Play", "Multiplayer", "Hero Shooter", "Competitive"],
    rating: "4.2",
    reviewCount: 876,
    features: [
      "Cross-play enabled",
      "Seasonal battle pass",
      "Ranked competitive mode",
      "Frequent content updates",
    ],
    ageRating: "T",
    releaseDate: "Aug 5, 2024",
    featured: false,
    collection: "Most Played",
  },
  {
    name: "Terra Formers",
    slug: "terra-formers",
    description:
      "Turn a barren alien planet into a thriving colony. Balance ecosystems, research bio-tech, and survive extreme weather in this relaxing survival sim.",
    price: "32.99",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1614726365723-49cfae9278b7?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1446776877081-d282a0f896e2?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 110,
    category: "Simulation",
    platform: ["PC", "Nintendo Switch"],
    tags: ["Survival", "Crafting", "Relaxing", "Sci-Fi"],
    rating: "4.5",
    reviewCount: 143,
    features: [
      "Terraforming simulation",
      "Weather systems",
      "Base building",
      "Creative and survival modes",
    ],
    ageRating: "E10+",
    releaseDate: "Jul 18, 2024",
    featured: false,
    collection: null,
  },
  {
    name: "Blade of the Ronin",
    slug: "blade-of-the-ronin",
    description:
      "Master the way of the blade in feudal Japan. Engage in precise sword combat, explore open villages, and choose honor or vengeance in this cinematic action adventure.",
    price: "54.99",
    comparePrice: "59.99",
    images: [
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1528360983277-13d401cdc186?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 92,
    category: "Action",
    platform: ["PC", "PlayStation 5"],
    tags: ["Samurai", "Open World", "Action Adventure", "Cinematic"],
    rating: "4.7",
    reviewCount: 267,
    features: [
      "Cinematic swordplay",
      "Dynamic weather",
      "Moral choice system",
      "Photo-realistic landscapes",
    ],
    ageRating: "M",
    releaseDate: "Jun 2, 2024",
    featured: true,
    collection: "Editor's Choice",
  },
  {
    name: "Void Runners",
    slug: "void-runners",
    description:
      "A high-octane roguelike shooter set in ever-shifting interdimensional dungeons. Collect wild weapons, unlock abilities, and escape the Void.",
    price: "21.99",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1555680202-c86f0e12f086?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 150,
    category: "Action",
    platform: ["PC", "Nintendo Switch"],
    tags: ["Roguelike", "Shooter", "Fast-Paced", "Indie"],
    rating: "4.4",
    reviewCount: 312,
    features: [
      "Procedural dungeons",
      "100+ unique weapons",
      "Daily challenges",
      "Local co-op",
    ],
    ageRating: "T",
    releaseDate: "May 14, 2024",
    featured: false,
    collection: null,
  },
  {
    name: "Farmhold Valley",
    slug: "farmhold-valley",
    description:
      "Leave the city behind and restore your grandfather's farm. Grow crops, raise animals, befriend townsfolk, and find romance in this cozy life sim.",
    price: "26.99",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1464226184884-fa280b87c399?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1473973266408-ed4e27abdd47?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 180,
    category: "Simulation",
    platform: ["PC", "Nintendo Switch", "PlayStation 5", "Xbox Series X"],
    tags: ["Cozy", "Farming Sim", "Life Sim", "Relaxing"],
    rating: "4.8",
    reviewCount: 421,
    features: [
      "Seasonal farming cycles",
      "Romanceable characters",
      "Fishing and mining",
      "Multiplayer farming",
    ],
    ageRating: "E",
    releaseDate: "Apr 9, 2024",
    featured: true,
    collection: "Cozy Picks",
  },
  {
    name: "Nexus Warriors",
    slug: "nexus-warriors",
    description:
      "A fast-paced arena brawler where elite fighters from across the galaxy clash. Master unique heroes, team up in 3v3 skirmishes, and climb the ranks in competitive seasons.",
    price: "39.99",
    comparePrice: null,
    images: [
      "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 250,
    category: "Action",
    platform: ["PC", "PlayStation 5", "Xbox Series X"],
    tags: ["Multiplayer", "Arena", "Competitive", "Brawler"],
    rating: "4.5",
    reviewCount: 278,
    features: [
      "20+ playable heroes",
      "Ranked competitive mode",
      "Cross-platform play",
      "Regular balance updates",
    ],
    ageRating: "T",
    releaseDate: "Mar 3, 2025",
    featured: true,
    collection: "GAMES",
  },
  {
    name: "Chrono Tactics",
    slug: "chrono-tactics",
    description:
      "Command time-bending units across historical battlefields. Rewind mistakes, flank enemies from the future, and reshape the timeline in this innovative turn-based strategy game.",
    price: "42.99",
    comparePrice: "49.99",
    images: [
      "https://images.unsplash.com/photo-1555680202-c86f0e12f086?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1560253023-3ec5d502959f?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80",
    ],
    stock: 95,
    category: "Strategy",
    platform: ["PC", "Nintendo Switch"],
    tags: ["Turn-Based", "Time Travel", "Tactical", "Strategy"],
    rating: "4.6",
    reviewCount: 165,
    features: [
      "Time rewind mechanics",
      "Historical campaigns",
      "Skirmish mode",
      "Map editor",
    ],
    ageRating: "T",
    releaseDate: "Feb 20, 2025",
    featured: false,
    collection: "GAMES",
  },
];

const reviewBodies = [
  [
    "Absolutely incredible. I lost track of time exploring every corner.",
    "The art direction is unmatched. A must-play for fans of the genre.",
    "Great game but the difficulty spikes near the end.",
  ],
  [
    "Best racing game I've played this year. The soundtrack slaps.",
    "Controls are tight and the customization is deep.",
    "Online matchmaking can be slow during off-hours.",
  ],
  [
    "Brutal, beautiful, and unforgettable. Every boss feels like an event.",
    "The world design is top tier. I love how everything connects.",
    "Not for casual players, but rewarding if you stick with it.",
  ],
  [
    "Complex but satisfying. One more turn syndrome is real.",
    "The diplomacy system could use more depth.",
    "A space strategy fan's dream come true.",
  ],
  [
    "So cozy and addictive. Perfect after a long day.",
    "The pixel art is gorgeous and the music is relaxing.",
    "Would love more late-game content.",
  ],
  [
    "The hacking mechanics feel fresh and tense.",
    "Great co-op experience with friends.",
    "Story is a bit predictable, but gameplay carries it.",
  ],
  [
    "Genuinely terrifying. Play with headphones at night.",
    "Atmosphere is incredible. I was on edge the whole time.",
    "Puzzles are clever and never too frustrating.",
  ],
  [
    "Fun hero shooter with unique characters.",
    "Microtransactions are fair for a free game.",
    "Servers have improved a lot since launch.",
  ],
  [
    "Relaxing survival game with a great loop.",
    "Terraforming feels meaningful and visual.",
    "Performance could be better on Switch.",
  ],
  [
    "A samurai epic that rivals the greats.",
    "Combat is precise and deeply satisfying.",
    "The world is stunning. I stopped to take photos constantly.",
  ],
  [
    "Crazy weapons, crazy fun. Roguelike perfection.",
    "Great with a friend on the couch.",
    "Can feel repetitive after a few runs.",
  ],
  [
    "The coziest farming game out there.",
    "Characters are charming and memorable.",
    "Hundreds of hours of content for the price.",
  ],
  [
    "Great hero variety and fun team fights.",
    "Matchmaking is quick and matches feel fair.",
    "Cosmetics are a bit pricey, but gameplay is solid.",
  ],
  [
    "Clever time mechanics that actually change strategy.",
    "Campaign missions are challenging and rewarding.",
    "Would love more factions in future updates.",
  ],
];

const firstNames = [
  "Alex",
  "Jordan",
  "Casey",
  "Morgan",
  "Riley",
  "Taylor",
  "Quinn",
  "Avery",
  "Sam",
  "Dakota",
];

export async function seedDatabase() {
  const existingSlugs = await db.select({ slug: products.slug }).from(products);
  const existingSlugSet = new Set(existingSlugs.map((p) => p.slug));

  const newProducts = productData.filter((p) => !existingSlugSet.has(p.slug));

  if (newProducts.length === 0) {
    return { seeded: false, message: "All demo products already exist" };
  }

  const insertedProducts = await db
    .insert(products)
    .values(newProducts)
    .returning({ id: products.id, slug: products.slug });

  const reviewInserts = insertedProducts.flatMap((product) => {
    const dataIndex = productData.findIndex((p) => p.slug === product.slug);
    const index = dataIndex >= 0 ? dataIndex : 0;
    const bodies = reviewBodies[index] ?? reviewBodies[0];
    return bodies.map((body, rIndex) => ({
      productId: product.id,
      author: `${firstNames[(index + rIndex) % firstNames.length]}${Math.floor(Math.random() * 99) + 1}`,
      rating: [5, 5, 4, 4, 5][Math.floor(Math.random() * 5)],
      title: ["Love it", "Solid title", "Great experience", "Highly recommend", "Fun"][
        rIndex
      ],
      body,
      helpful: Math.floor(Math.random() * 50),
      verified: Math.random() > 0.3,
    }));
  });

  await db.insert(reviews).values(reviewInserts);

  return { seeded: true, count: insertedProducts.length };
}
