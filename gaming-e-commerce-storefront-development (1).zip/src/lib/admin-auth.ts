import { NextRequest, NextResponse } from "next/server";

export const ADMIN_ID = "12345678";

export function requireAdmin(request: NextRequest) {
  const adminId = request.headers.get("x-admin-id");
  if (adminId !== ADMIN_ID) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return null;
}
